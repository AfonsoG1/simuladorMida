from motorEventsDiscrets import motorEventsDiscrets


def main():
        motor=motorEventsDiscrets()
        motor.run(None)

if __name__ == "__main__":
    main()
